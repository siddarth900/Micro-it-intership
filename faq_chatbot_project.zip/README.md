
# Internship FAQ Chatbot

This is a simple AI-powered chatbot that answers frequently asked questions about internships, application processes, and organization details using Dialogflow.

## 🔧 Setup Instructions

### 1. Dialogflow Setup
- Go to [Dialogflow Console](https://dialogflow.cloud.google.com/)
- Create a new agent
- Import the provided `agent-export.zip` file
- Navigate to "Integrations" > Enable "Web Demo" or use your own API

### 2. Web UI
- Open `index.html` in a browser
- Replace `YOUR_DIALOGFLOW_CLIENT_ACCESS_TOKEN` in `script.js` with your Dialogflow client token

## 💬 Example Questions
- What internships do you offer?
- How can I apply?
- Where is your office located?
- Is this internship paid?

## 📁 Files
- `index.html` – Main chatbot interface
- `style.css` – Styling
- `script.js` – API integration
- `agent-export.zip` – Dialogflow intents

## 🧠 Improvements
- Add backend with webhook fulfillment
- Store chat history
- Train on more user queries
