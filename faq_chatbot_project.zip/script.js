
const chatbox = document.getElementById('chatbox');

function sendMessage() {
    const input = document.getElementById('userInput');
    const message = input.value.trim();
    if (!message) return;

    chatbox.innerHTML += `<div><strong>You:</strong> ${message}</div>`;
    input.value = '';

    fetch('https://api.dialogflow.com/v1/query?v=20150910', {
        method: 'POST',
        headers: {
            'Authorization': 'Bearer YOUR_DIALOGFLOW_CLIENT_ACCESS_TOKEN',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            query: message,
            lang: 'en',
            sessionId: '123456'
        })
    })
    .then(res => res.json())
    .then(data => {
        const reply = data.result.fulfillment.speech;
        chatbox.innerHTML += `<div><strong>Bot:</strong> ${reply}</div>`;
        chatbox.scrollTop = chatbox.scrollHeight;
    });
}
